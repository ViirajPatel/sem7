<style>
	.footer {
		height: 200px;
		background-image: linear-gradient(white, #e6f7ff);
		/* background-color: #e6e6e6; */
	}
</style>
<div class="footer" align=right>
	Created by-Viraj</a>
</div>