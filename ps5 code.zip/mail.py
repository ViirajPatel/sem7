import smtplib
import sys
server = smtplib.SMTP('smtp.gmail.com', 587)
server.ehlo()
server.starttls()
server.ehlo()
mailadd = sys.argv[1]
# print(mailadd)
server.login('v7046529350@gmail.com', 'Jjpatel@7985')

subject = "OTP"

body = sys.argv[2]
#
msg = f"Subject : {subject}\n\n{body}"

# 'vjp264@hotmail.com'
server.sendmail('v7046529350@gmail.com',mailadd , msg)

print("sent")
server.quit()
