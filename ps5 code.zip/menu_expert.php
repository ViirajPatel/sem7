<div class="scrollmenu">
<a href="expert_index.php">Query</a>
<a href="logout.php">Logout</a>
</div>