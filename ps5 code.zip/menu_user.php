<div class="scrollmenu">
    <a href="user_index.php">Home</a>
    <a href="update_user.php?sts=edit_profile&msg=bs">Edit Profile</a>
    <a href="query.php">Query</a>
    <a href="weather.php">weather</a>
    <a href="commodityprice.php">Price</a>
    <a href="logout.php">Logout</a>
</div>