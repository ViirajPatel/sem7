<div class="scrollmenu">
    <a href="edit_users.php">User's list</a>
    <a href="update_user.php?sts=edit_profile&msg=bs&kng=0">Edit Profile</a>

    <a href="addcrop.php">Add Crop</a>
    <a href="logout.php">Logout</a>
</div>
<style>
    div.scrollmenu {
        background-color: #333;
        overflow: auto;
        white-space: nowrap;
    }

    div.scrollmenu a {
        display: inline-block;
        color: white;
        text-align: center;
        padding: 14px;
        text-decoration: none;
    }

    div.scrollmenu a:hover {
        background-color: #777;
    }
</style>