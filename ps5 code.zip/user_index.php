<?php

include("header.php");
include("menu_user.php");
?>
<style>
    .container{
        padding: 15px 15px 15px 15px;
    box-shadow: 0 4px 8px 0 rgba(0, 0, 0, 0.2), 0 6px 20px 0 rgba(0, 0, 0, 0.19);
    }
</style>
<hr>
<div class="container">
    <br><?php
    include("showcropinfo.php");
    ?><br>
</div>
<hr>
<?php
include("footer.php");
?>