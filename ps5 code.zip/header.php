 <style>
 	div {
 		font-family: 'Trebuchet MS', 'Lucida Sans Unicode', 'Lucida Grande', 'Lucida Sans', Arial, sans-serif;
 	}

 	.hfa {
 		background-image: linear-gradient(#e6f7ff, white);
 		/* background-color: #e6e6e6; */
 		height: 300px;
 		font-weight: bolder;
 		vertical-align: middle;
 		padding-top: 30px;
 		padding-bottom: 30px;
 		margin-bottom: 30px;
 		font-family: 'Trebuchet MS', 'Lucida Sans Unicode', 'Lucida Grande', 'Lucida Sans', Arial, sans-serif;
 		color: darkslategrey;
 	}
 </style>
 <style>
 	div.scrollmenu {

 		background-color: #333;
 		overflow: auto;
 		white-space: nowrap;
 	}

 	div.scrollmenu a {
 		display: inline-block;
 		color: white;
 		text-align: center;
 		padding: 14px;
 		text-decoration: none;
 	}

 	div.scrollmenu a:hover {
 		background-color: #777;
 	}
 </style>

 <link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
 <script src="jquery.js"></script>
 <script src="bootstrap.js"></script>
 <!-- 
 <div class="header" text-align="center">
 	<h1 class="res">Horticultural Farming Adviser</h1>
 </div> -->
 <div class="hfa" align="center">
 	<p style="font-size: 63px;">Horticultural Farming Adviser</p>
 </div>