consumer_key= '7x7w8Ti8GmMtuhvj7IXBuvZmP'
consumer_secret= 'kpFGcKiGxP9dJtlQzZ99p2OK9HM0IjA1I8n23N40VJyctOzvkG'

access_token='1365544389498474497-97lzyZE9lroLNDzLhvW1dLS3MDKfV5'
access_token_secret='8mF9CrBt4SvmewPZaapgL7kkh2iJus824SvhBJOvDpXlw'

num_of_tweets = int(300)
